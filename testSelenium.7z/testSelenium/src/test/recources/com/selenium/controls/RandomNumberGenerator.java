package com.selenium.controls;

public class RandomNumberGenerator {

	public static String GenerateRandomNumber() {
		// TODO Auto-generated method stub
		return null;
	}

}
